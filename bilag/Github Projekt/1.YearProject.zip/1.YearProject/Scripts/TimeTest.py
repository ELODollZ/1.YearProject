import time
from datetime import datetime
Time = time.ctime()
print(Time)